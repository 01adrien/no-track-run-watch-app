import Toybox.Lang;
import Toybox.WatchUi;

class NoTrackRunDelegate extends WatchUi.InputDelegate {

    function initialize() {
        InputDelegate.initialize();
    }

    function onKey(keyEvent as KeyEvent) as Boolean {
        var key = keyEvent.getKey();
        var app = Application.getApp() as NoTrackRunApp;

        if (key == WatchUi.KEY_UP) {
            app.updateSession(app.sessionData.blocks[app.currentBlockIndex].duration);
        } else if (key == WatchUi.KEY_DOWN) {
            // reculer block (debug)
            if (app.currentBlockIndex > 0) {
                app.currentBlockIndex -= 1;
                app.elapsedTime = 0;
            }
        }

        WatchUi.requestUpdate();
        return true;
    }
}

