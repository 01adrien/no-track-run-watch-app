import Toybox.Graphics;
import Toybox.WatchUi;

class NoTrackRunView extends WatchUi.View {

    function initialize() {
        View.initialize();
    }

    function onUpdate(dc as Dc) as Void {
        dc.clear();
        dc.setColor(Graphics.COLOR_WHITE, Graphics.COLOR_BLACK);

        var app = Application.getApp() as NoTrackRunApp;

        // afficher nom session
        dc.drawText(dc.getWidth()/2, 20, Graphics.FONT_MEDIUM, app.sessionData.label, Graphics.TEXT_JUSTIFY_CENTER | Graphics.TEXT_JUSTIFY_VCENTER);

        // afficher block courant
        if (app.currentBlockIndex < app.sessionData.blocks.size()) {
            var block = app.sessionData.blocks[app.currentBlockIndex];
            dc.drawText(dc.getWidth()/2, 50, Graphics.FONT_SMALL, "Block: " + block.label, Graphics.TEXT_JUSTIFY_CENTER | Graphics.TEXT_JUSTIFY_VCENTER);
            dc.drawText(dc.getWidth()/2, 70, Graphics.FONT_SMALL, "Elapsed: " + app.elapsedTime + "s / " + block.duration + "s", Graphics.TEXT_JUSTIFY_CENTER | Graphics.TEXT_JUSTIFY_VCENTER);
            dc.drawText(dc.getWidth()/2, 90, Graphics.FONT_SMALL, "Intensity: " + block.intensity, Graphics.TEXT_JUSTIFY_CENTER | Graphics.TEXT_JUSTIFY_VCENTER);
        } else {
            dc.drawText(dc.getWidth()/2, 50, Graphics.FONT_MEDIUM, "Session terminée !", Graphics.TEXT_JUSTIFY_CENTER | Graphics.TEXT_JUSTIFY_VCENTER);
        }
    }
}