import Toybox.Application;
import Toybox.Lang;
import Toybox.WatchUi;

import Toybox.Application;
import Toybox.Lang;
import Toybox.WatchUi;
import Toybox.Communications;
import Toybox.System;

// ------------------ APP ------------------
class NoTrackRunApp extends Application.AppBase {

    // Stocke la session complète
    var sessionData as Dictionary;
    var currentBlockIndex as Number;
    var elapsedTime as Number;
    var results as Array;
    var vma as Number;

    function initialize() {
        AppBase.initialize();
        sessionData = {};
        currentBlockIndex = 0;
        elapsedTime = 0;
        results = [];
        vma = 15;
    }

    function onStart(state as Dictionary?) as Void {
        // Simulation : session reçue depuis le téléphone
        receiveSession();
    }

    function onStop(state as Dictionary?) as Void {
        // Ici tu pourrais envoyer les résultats au téléphone
        System.println("Session terminée : " + results.toString());
    }

    function getInitialView() as [Views] or [Views, InputDelegates] {
        return [ new NoTrackRunView(), new NoTrackRunDelegate() ];
    }

    // ------------------ SIMULER BLE ------------------
    function receiveSession() as Void {
        var sessionData = {
            "label" => "Endurance",
            "date" => "2026-03-02"
            "blocks" => [
                {
                    "label" => "cooling down",
                    "fields" => [
                        { "distance" => 4000, "duration" => 1000},
                        { "data" => 1000, "unit" => "m" }
                    ]
                }
            ]
        };
        currentBlockIndex = 0;
        elapsedTime = 0;
        results = [];
    }

    // ------------------ LOGIQUE BLOCK ------------------
    function updateSession(deltaTime as Number) as Void {
        if (currentBlockIndex >= sessionData.blocks.size()) {
            return; // session terminée
        }

        elapsedTime += deltaTime;
        var block = sessionData.blocks[currentBlockIndex];

        if (elapsedTime >= block.duration) {
            results.add({
                blockOrder: block.order,
                duration: elapsedTime,
                success: 1
            });

            // passer au bloc suivant
            currentBlockIndex += 1;
            elapsedTime = 0;

            // session terminée ?
            if (currentBlockIndex >= sessionData.blocks.size()) {
                System.println("Session terminée !");
            }
        }
    }
}


function getApp() as no_track_run_watchApp {
    return Application.getApp() as no_track_run_watchApp;
}